#ifndef INC_RJ_ELEKTRONIK_MAX7219_H_
#define INC_RJ_ELEKTRONIK_MAX7219_H_

#include "stm32f1xx_hal.h"

#define CS_PIN GPIO_PIN_6
#define CS_PORT GPIOA
#define LARGEUR 8
#define HAUTEUR 8

typedef enum {
    MAX7219_REG_NOOP = 0x00,
    MAX7219_REG_DECODEMODE = 0x09,
    MAX7219_REG_INTENSITY = 0x0A,
    MAX7219_REG_SCANLIMIT = 0x0B,
    MAX7219_REG_SHUTDOWN = 0x0C,
    MAX7219_REG_DISPLAYTEST = 0x0F,
    MAX7219_REG_DIGIT0 = 0x01
} max7219_registers_t;

// Macro pour le contrôle SPI
#define CS_LOW() HAL_GPIO_WritePin(CS_PORT, CS_PIN, GPIO_PIN_RESET)
#define CS_HIGH() HAL_GPIO_WritePin(CS_PORT, CS_PIN, GPIO_PIN_SET)
#define SPI_Transmit(data) HAL_SPI_Transmit(&hspi1, &data, 1, 10)


// Fonctions de base
void MAX7219_Init(void);
void MAX7219_SetRegister(uint8_t reg, uint8_t value);
void MAX7219_Clean(void);
void MAX7219_ShowMatrix(uint8_t matrix[LARGEUR][HAUTEUR]);
int MAX7219_Show_Pixel(uint8_t x, uint8_t y);
void MAX7219_ClearPixel(uint8_t x, uint8_t y);
void MAX7219_TogglePixel(uint8_t x, uint8_t y);
void MAX7219_SetIntensity(uint8_t intensity);

// Fonctions avancées
void MAX7219_DrawLine(uint8_t x1, uint8_t y1, uint8_t x2, uint8_t y2);
void MAX7219_DrawRectangle(uint8_t x1, uint8_t y1, uint8_t x2, uint8_t y2, uint8_t filled);
void MAX7219_DrawCircle(uint8_t x0, uint8_t y0, uint8_t radius);
void MAX7219_DisplayChar(char c);
void MAX7219_ScrollText(const char* text, uint16_t delay_ms, uint8_t loop);
void MAX7219_LoadPattern(const uint8_t pattern[LARGEUR][HAUTEUR]);
void MAX7219_TestMatrix(uint16_t delay_ms);
void MAX7219_DisplayText(const char* text, uint8_t length) ;

#endif /* INC_RJ_ELEKTRONIK_MAX7219_H_ */
