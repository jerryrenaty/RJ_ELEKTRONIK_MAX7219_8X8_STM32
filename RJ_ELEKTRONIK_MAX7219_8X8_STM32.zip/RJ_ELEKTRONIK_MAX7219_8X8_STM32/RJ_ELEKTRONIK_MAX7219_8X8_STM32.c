#include "RJ_ELEKTRONIK_MAX7219_8X8_STM32.h"
#include <stdlib.h>
#include "stm32f1xx_hal.h"

uint8_t ledMatrix[LARGEUR][HAUTEUR] = {0};
extern  SPI_HandleTypeDef hspi1;

// Fonction interne pour écrire dans un registre
void MAX7219_SetRegister(uint8_t reg, uint8_t value) {
    CS_LOW();
    SPI_Transmit(reg);
    SPI_Transmit(value);
    CS_HIGH();
}


void MAX7219_Init(void) {

    uint8_t init_seq[][2] = {
        {MAX7219_REG_SCANLIMIT, 0x07},
        {MAX7219_REG_DECODEMODE, 0x00},
        {MAX7219_REG_SHUTDOWN, 0x01},
        {MAX7219_REG_DISPLAYTEST, 0x00},
        {MAX7219_REG_INTENSITY, 0x04}
    };

    for(uint8_t i = 0; i < sizeof(init_seq)/sizeof(init_seq[0]); i++) {
        MAX7219_SetRegister(init_seq[i][0], init_seq[i][1]);
    }
    MAX7219_Clean();
}

void MAX7219_Clean(void) {
    for(uint8_t i = 0; i < LARGEUR; i++) {
        for(uint8_t j = 0; j < HAUTEUR; j++) {
            ledMatrix[i][j] = 0;
        }
        MAX7219_SetRegister(i + 1, 0x00);
    }
}

void MAX7219_ShowMatrix(uint8_t matrix[LARGEUR][HAUTEUR]) {
    for(uint8_t i = 0; i < LARGEUR; i++) {
        uint8_t data = 0;
        for(uint8_t j = 0; j < HAUTEUR; j++) {
            if(matrix[i][j]) data |= (1 << j);
        }
        MAX7219_SetRegister(i + 1, data);
    }
}

int MAX7219_Show_Pixel(uint8_t x, uint8_t y) {
    if(x >= LARGEUR || y >= HAUTEUR) return -1;
    ledMatrix[x][y] = 1;
    MAX7219_ShowMatrix(ledMatrix);
    return y * LARGEUR + x;
}

void MAX7219_ClearPixel(uint8_t x, uint8_t y) {
    if(x < LARGEUR && y < HAUTEUR) {
        ledMatrix[x][y] = 0;
        MAX7219_ShowMatrix(ledMatrix);
    }
}

void MAX7219_TogglePixel(uint8_t x, uint8_t y) {
    if(x < LARGEUR && y < HAUTEUR) {
        ledMatrix[x][y] ^= 1;
        MAX7219_ShowMatrix(ledMatrix);
    }
}

void MAX7219_SetIntensity(uint8_t intensity) {
    if(intensity > 15) intensity = 15;
    MAX7219_SetRegister(MAX7219_REG_INTENSITY, intensity);
}

void MAX7219_DrawLine(uint8_t x1, uint8_t y1, uint8_t x2, uint8_t y2) {
    int16_t dx = abs(x2 - x1);
    int16_t dy = abs(y2 - y1);
    int8_t sx = (x1 < x2) ? 1 : -1;
    int8_t sy = (y1 < y2) ? 1 : -1;
    int16_t err = (dx > dy ? dx : -dy) / 2;

    while(1) {
        MAX7219_Show_Pixel(x1, y1);
        if(x1 == x2 && y1 == y2) break;
        int16_t e2 = err;
        if(e2 > -dx) { err -= dy; x1 += sx; }
        if(e2 < dy) { err += dx; y1 += sy; }
    }
}

void MAX7219_DrawRectangle(uint8_t x1, uint8_t y1, uint8_t x2, uint8_t y2, uint8_t filled) {
    if(filled) {
        for(uint8_t x = x1; x <= x2; x++) {
            for(uint8_t y = y1; y <= y2; y++) {
                MAX7219_Show_Pixel(x, y);
            }
        }
    } else {
        for(uint8_t x = x1; x <= x2; x++) {
            MAX7219_Show_Pixel(x, y1);
            MAX7219_Show_Pixel(x, y2);
        }
        for(uint8_t y = y1; y <= y2; y++) {
            MAX7219_Show_Pixel(x1, y);
            MAX7219_Show_Pixel(x2, y);
        }
    }
}

void MAX7219_DrawCircle(uint8_t x0, uint8_t y0, uint8_t radius) {
    int16_t x = radius;
    int16_t y = 0;
    int16_t err = 0;

    while(x >= y) {
        MAX7219_Show_Pixel(x0 + x, y0 + y);
        MAX7219_Show_Pixel(x0 + y, y0 + x);
        MAX7219_Show_Pixel(x0 - y, y0 + x);
        MAX7219_Show_Pixel(x0 - x, y0 + y);
        MAX7219_Show_Pixel(x0 - x, y0 - y);
        MAX7219_Show_Pixel(x0 - y, y0 - x);
        MAX7219_Show_Pixel(x0 + y, y0 - x);
        MAX7219_Show_Pixel(x0 + x, y0 - y);

        y += 1;
        err += 1 + 2*y;
        if(2*(err - x) + 1 > 0) {
            x -= 1;
            err += 1 - 2*x;
        }
    }
}

// Police de caractères 8x8 étendue (chiffres + lettres majuscules A-Z)
static const uint8_t font[36][8] = {
    // Chiffres 0-9 (identique à votre version)
    {0x3E, 0x63, 0x73, 0x7B, 0x6F, 0x67, 0x3E, 0x00}, // 0
    {0x0C, 0x0E, 0x0C, 0x0C, 0x0C, 0x0C, 0x3F, 0x00}, // 1
    {0x1E, 0x33, 0x30, 0x1C, 0x06, 0x33, 0x3F, 0x00}, // 2
    {0x1E, 0x33, 0x30, 0x1C, 0x30, 0x33, 0x1E, 0x00}, // 3
    {0x38, 0x3C, 0x36, 0x33, 0x7F, 0x30, 0x30, 0x00}, // 4
    {0x3F, 0x03, 0x1F, 0x30, 0x30, 0x33, 0x1E, 0x00}, // 5
    {0x1C, 0x06, 0x03, 0x1F, 0x33, 0x33, 0x1E, 0x00}, // 6
    {0x3F, 0x33, 0x30, 0x18, 0x0C, 0x06, 0x06, 0x00}, // 7
    {0x1E, 0x33, 0x33, 0x1E, 0x33, 0x33, 0x1E, 0x00}, // 8
    {0x1E, 0x33, 0x33, 0x3E, 0x30, 0x18, 0x0E, 0x00}, // 9

    // Lettres A-Z
    {0x1C, 0x36, 0x63, 0x63, 0x7F, 0x63, 0x63, 0x00}, // A
    {0x3F, 0x66, 0x66, 0x3E, 0x66, 0x66, 0x3F, 0x00}, // B
    {0x3C, 0x66, 0x03, 0x03, 0x03, 0x66, 0x3C, 0x00}, // C
    {0x1F, 0x36, 0x66, 0x66, 0x66, 0x36, 0x1F, 0x00}, // D
    {0x7F, 0x46, 0x16, 0x1E, 0x16, 0x46, 0x7F, 0x00}, // E
    {0x7F, 0x46, 0x16, 0x1E, 0x16, 0x06, 0x0F, 0x00}, // F
    {0x3C, 0x66, 0x03, 0x03, 0x73, 0x66, 0x7C, 0x00}, // G
    {0x63, 0x63, 0x63, 0x7F, 0x63, 0x63, 0x63, 0x00}, // H
    {0x3C, 0x18, 0x18, 0x18, 0x18, 0x18, 0x3C, 0x00}, // I
    {0x78, 0x30, 0x30, 0x30, 0x33, 0x33, 0x1E, 0x00}, // J
    {0x67, 0x66, 0x36, 0x1E, 0x36, 0x66, 0x67, 0x00}, // K
    {0x0F, 0x06, 0x06, 0x06, 0x46, 0x66, 0x7F, 0x00}, // L
    {0x63, 0x77, 0x7F, 0x7F, 0x6B, 0x63, 0x63, 0x00}, // M
    {0x63, 0x67, 0x6F, 0x7B, 0x73, 0x63, 0x63, 0x00}, // N
    {0x1C, 0x36, 0x63, 0x63, 0x63, 0x36, 0x1C, 0x00}, // O
    {0x3F, 0x66, 0x66, 0x3E, 0x06, 0x06, 0x0F, 0x00}, // P
    {0x1E, 0x33, 0x33, 0x33, 0x3B, 0x1E, 0x38, 0x00}, // Q
    {0x3F, 0x66, 0x66, 0x3E, 0x36, 0x66, 0x67, 0x00}, // R
    {0x1E, 0x33, 0x07, 0x0E, 0x38, 0x33, 0x1E, 0x00}, // S
    {0x3F, 0x2D, 0x0C, 0x0C, 0x0C, 0x0C, 0x1E, 0x00}, // T
    {0x33, 0x33, 0x33, 0x33, 0x33, 0x33, 0x3F, 0x00}, // U
    {0x33, 0x33, 0x33, 0x33, 0x33, 0x1E, 0x0C, 0x00}, // V
    {0x63, 0x63, 0x63, 0x6B, 0x7F, 0x77, 0x63, 0x00}, // W
    {0x63, 0x63, 0x36, 0x1C, 0x1C, 0x36, 0x63, 0x00}, // X
    {0x33, 0x33, 0x33, 0x1E, 0x0C, 0x0C, 0x1E, 0x00}, // Y
    {0x7F, 0x63, 0x31, 0x18, 0x4C, 0x66, 0x7F, 0x00}  // Z
};
void MAX7219_DisplayChar(char c) {
    uint8_t index = 0;

    if(c >= '0' && c <= '9') {
        index = c - '0';
    }
    else if(c >= 'A' && c <= 'Z') {
        index = 10 + (c - 'A'); // 10-35 pour A-Z
    }
    else if(c >= 'a' && c <= 'z') {
        index = 10 + (c - 'a'); // 10-35 pour a-z (même forme que A-Z)
    }
    else {
        // Caractère non reconnu - afficher un espace
        for(uint8_t i = 0; i < 8; i++) {
            MAX7219_SetRegister(i + 1, 0x00);
        }
        return;
    }

    for(uint8_t i = 0; i < 8; i++) {
        MAX7219_SetRegister(i + 1, font[index][i]);
    }
}

void MAX7219_ScrollText(const char* text, uint16_t delay_ms, uint8_t loop) {
    uint8_t buffer[8] = {0};
    uint8_t char_pos = 0;
    uint16_t current_char_index = 0;
    uint8_t blank_space_added = 0;

    do {
        // Décalage du buffer vers la gauche
        for(uint8_t i = 0; i < 7; i++) {
            buffer[i] = buffer[i+1];
        }
        buffer[7] = 0x00;

        // Si on a un caractère à afficher
        if(text[current_char_index] != '\0') {
            if(char_pos < 8) {
             //   uint8_t char_data = 0x00;
                uint8_t font_index = 0;

                // Trouver l'index dans la police
                if(text[current_char_index] >= '0' && text[current_char_index] <= '9') {
                    font_index = text[current_char_index] - '0';
                }
                else if(text[current_char_index] >= 'A' && text[current_char_index] <= 'Z') {
                    font_index = 10 + (text[current_char_index] - 'A');
                }
                else if(text[current_char_index] >= 'a' && text[current_char_index] <= 'z') {
                    font_index = 10 + (text[current_char_index] - 'a');
                }

                // Ajouter la colonne au buffer
                buffer[7] = font[font_index][char_pos];
                char_pos++;
                blank_space_added = 0;
            }

            // Passer au caractère suivant si on a fini le courant
            if(char_pos >= 8) {
                char_pos = 0;
                current_char_index++;
            }
        }
        else {
            // Fin du texte - ajouter un espace si pas déjà fait
            if(!blank_space_added) {
                buffer[7] = 0x00;
                blank_space_added = 1;
            }

            // Si en mode boucle, recommencer
            if(loop) {
                current_char_index = 0;
            }
            else {
                // Dernier défilement pour faire sortir le texte
                uint8_t empty = 1;
                for(uint8_t i = 0; i < 8; i++) {
                    if(buffer[i] != 0x00) {
                        empty = 0;
                        break;
                    }
                }
                if(empty) break;
            }
        }

        // Afficher le buffer
        for(uint8_t i = 0; i < 8; i++) {
            MAX7219_SetRegister(i + 1, buffer[i]);
        }

        HAL_Delay(delay_ms);
    } while(1);
}

void MAX7219_LoadPattern(const uint8_t pattern[LARGEUR][HAUTEUR]) {
    for(uint8_t i = 0; i < LARGEUR; i++) {
        for(uint8_t j = 0; j < HAUTEUR; j++) {
            ledMatrix[i][j] = pattern[i][j];
        }
    }
    MAX7219_ShowMatrix(ledMatrix);
}

void MAX7219_TestMatrix(uint16_t delay_ms) {
    // Test toutes les LEDs une par une
    for(uint8_t i = 0; i < LARGEUR; i++) {
        for(uint8_t j = 0; j < HAUTEUR; j++) {
            MAX7219_Clean();
            MAX7219_Show_Pixel(i, j);
            HAL_Delay(delay_ms);
        }
    }

    // Test d'intensité
    for(uint8_t i = 0; i < 16; i++) {
        MAX7219_SetIntensity(i);
        HAL_Delay(100);
    }
    MAX7219_SetIntensity(8);
}

void MAX7219_DisplayText(const char* text, uint8_t length) {
    for(uint8_t i = 0; i < length && text[i] != '\0'; i++) {
        MAX7219_DisplayChar(text[i]);
        HAL_Delay(500); // Délai entre les caractères
    }
}
